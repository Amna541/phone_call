# Phone Call Intercepting Sample

This project is sample application that demonstrates intercepting and rejecting incoming phone calls on Android.

![](https://cdn-images-1.medium.com/max/800/1*PcSSxnA2NpDSv8hrJBeFlw.jpeg)

It's a source code for the following article on the medium:

- https://medium.com/@zoransasko/detecting-and-rejecting-incoming-phone-calls-on-android-9e0cff04ef20

