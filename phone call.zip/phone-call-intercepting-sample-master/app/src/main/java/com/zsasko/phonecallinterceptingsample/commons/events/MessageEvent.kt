package com.zsasko.phonecallinterceptingsample.commons.events

class MessageEvent(val message: String) {}