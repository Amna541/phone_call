package com.zsasko.phonecallinterceptingsample.commons

const val TEL_PREFIX = "tel:"

const val FORBIDDEN_PHONE_CALL_NUMBER = "6505551212"